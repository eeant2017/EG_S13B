//-----------------------------------------------------------------------------
//	file name:		crc16check.h
//	function:		Header file of crc16check.c
//	author:			
//	date:			
//					Copyright(c) ZhiAnTech Coporation,2017
//-----------------------------------------------------------------------------

#include <project.h>

uint32 MyCrc16Check(uint8 *MyChar, uint32 Mylen);




